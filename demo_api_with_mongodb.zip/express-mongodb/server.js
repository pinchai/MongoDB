const express = require("express");
const { MongoClient, ObjectId } = require("mongodb");

const app = express();

app.use(express.json());

// MongoDB Configuration
const PORT = 3000;
const MONGO_URI = "mongodb://127.0.0.1:27017";
const DB_NAME = "school_db";

// MongoDB Connection
const client = new MongoClient(MONGO_URI);

let students;

// Connect Database
async function connectDB() {
    try {
        await client.connect();

        const db = client.db(DB_NAME);
        students = db.collection("students");

        console.log("MongoDB Connected!");

        app.listen(PORT, () => {
            console.log(`Server running at http://localhost:${PORT}`);
        });

    } catch (error) {
        console.error("Database Connection Error:", error);
        process.exit(1);
    }
}

// ====================================
// CRUD API
// ====================================

// GET: Display all students
app.get("/students", async (req, res) => {
    try {
        const data = await students.find().toArray();
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// GET: Display student by ID
app.get("/students/:id", async (req, res) => {
    try {
        const data = await students.findOne({
            _id: new ObjectId(req.params.id)
        });

        if (!data) {
            return res.status(404).json({ message: "Student not found" });
        }

        res.json(data);
    } catch (error) {
        res.status(400).json({ message: "Invalid ID" });
    }
});

// POST: Create student
app.post("/students", async (req, res) => {
    try {
        const result = await students.insertOne(req.body);

        res.status(201).json({
            message: "Student created successfully",
            insertedId: result.insertedId
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// PUT: Update student
app.put("/students/:id", async (req, res) => {
    try {
        const result = await students.updateOne(
            { _id: new ObjectId(req.params.id) },
            { $set: req.body }
        );

        if (result.matchedCount === 0) {
            return res.status(404).json({ message: "Student not found" });
        }

        res.json({ message: "Student updated successfully" });
    } catch (error) {
        res.status(400).json({ message: "Invalid ID or data" });
    }
});

// DELETE: Delete student
app.delete("/students/:id", async (req, res) => {
    try {
        const result = await students.deleteOne({
            _id: new ObjectId(req.params.id)
        });

        if (result.deletedCount === 0) {
            return res.status(404).json({ message: "Student not found" });
        }

        res.json({ message: "Student deleted successfully" });
    } catch (error) {
        res.status(400).json({ message: "Invalid ID" });
    }
});

// Start Application
connectDB();
